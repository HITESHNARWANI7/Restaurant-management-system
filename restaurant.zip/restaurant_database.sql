-- MariaDB dump 10.19  Distrib 10.4.22-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: restaurant
-- ------------------------------------------------------
-- Server version	10.4.22-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer` (
  `c_id` int(11) NOT NULL AUTO_INCREMENT,
  `c_name` varchar(100) DEFAULT NULL,
  `c_email` varchar(100) DEFAULT NULL,
  `order_date` date DEFAULT NULL,
  `ammount` int(11) DEFAULT NULL,
  PRIMARY KEY (`c_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (1,'hitesh','hiteshnarwani111@gmail.com','2022-03-12',798),(2,'navratan','navratanjat8875@gmail.com','2022-03-12',354),(3,'hitesh','hiteshnarwani111@gmail.com','2022-03-12',2134),(4,'gulshan','gulshan.bundel@gmail.com','2022-03-12',1770),(5,'atul','atulsharma111@gmail.com','2022-03-14',316),(6,'ajay sharma','ajaysharma111@gmail.com','2022-03-20',1260),(7,'mukul','mukulsoni@gmail.com','2022-03-21',906),(8,'jk','jak.123@gmail.com','2022-03-21',60);
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rating`
--

DROP TABLE IF EXISTS `rating`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rating` (
  `r_id` int(11) NOT NULL AUTO_INCREMENT,
  `c_name` varchar(100) DEFAULT NULL,
  `c_email` varchar(100) NOT NULL,
  `rate` int(11) DEFAULT NULL,
  `review_mes` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`r_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rating`
--

LOCK TABLES `rating` WRITE;
/*!40000 ALTER TABLE `rating` DISABLE KEYS */;
INSERT INTO `rating` VALUES (2,'Hitesh','hiteshnarwani111@gmail.com',5,'Good service, good food, good management, family environment place'),(3,'Gulshan','gulshan.bundel@gmail.com',4,'Good food facilities'),(4,'Atul','atulsharma@gmail.com',3,'It pollutes the environment and give a bad sign of that area.'),(5,'Ajay','ajaypandit@gmail.com',2,'Green, nice pathway, divided into different different sections. So that every age group can use according to their convenience.'),(6,'Abhishek','abhi111@gmail.com',5,'Better opportunity and space'),(7,'Mukul','mukulsoni@gmail.com',4,'Good food facilities'),(8,'Rajveer','rajveersharma@gmail.com',5,'Better opportunity and space'),(9,'Vicky','vickey11@gmail.com',4,'Normal park for the area'),(10,'Somendra','somendrasoni@gmail.com',5,'Loved it.'),(11,'Navratan','navratanjat8875@gmail.com',1,'staff behaviour is not good'),(12,'Gaurav','gauravkhatri111@gmail.com',2,' bad food'),(13,'Ajay','ajaysharma111@gmail.com',5,'good food');
/*!40000 ALTER TABLE `rating` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Hitesh','hiteshnarwani111@gmail.com','Hitesh!321'),(6,'Navratan','navratanjat8875@gmail.com','Navratan!321');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `veg`
--

DROP TABLE IF EXISTS `veg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `veg` (
  `code` int(11) NOT NULL AUTO_INCREMENT,
  `Item_name` varchar(100) NOT NULL,
  `price` int(11) NOT NULL,
  `item_key` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=455 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `veg`
--

LOCK TABLES `veg` WRITE;
/*!40000 ALTER TABLE `veg` DISABLE KEYS */;
INSERT INTO `veg` VALUES (1,'Chicken Chilli',140,'starters'),(2,'Chicken Tandoori',210,'starters'),(3,'Chicken Tikka',150,'starters'),(4,'Malai Tikka',180,'starters'),(5,'Fish Pakoda',160,'starters'),(6,'Fish Tikka',170,'starters'),(7,'Fish Fry',160,'starters'),(8,'Egg Bhurji',60,'starters'),(9,'Chicken Korma',320,'chicken'),(10,'Chicken Curry',230,'chicken'),(11,'Handi Chicken',300,'chicken'),(12,'Kadai Chicken',300,'chicken'),(13,'Butter Chicken',310,'chicken'),(14,'Chicken Changeji',300,'chicken'),(15,'Chicken Takka Masala',260,'chicken'),(16,'Chicken Hyderabadi',270,'chicken'),(17,'Chicken Masala',270,'chicken'),(18,'Chicken Keema Masala',320,'chicken'),(19,'Chicken Kolapuri',300,'chicken'),(20,'Mutton Korma',250,'mutton'),(21,'Mutton Bhuna Masala',260,'mutton'),(22,'Mutton Curry',240,'mutton'),(23,'Mutton Handi',260,'mutton'),(24,'Mutton Kadai',280,'mutton'),(25,'Mutton Hyderabadi',250,'mutton'),(26,'Mutton Roganjosh',260,'mutton'),(27,'Lal Maans',300,'mutton'),(28,'Egg Curry',100,'egg'),(29,'Egg Omlete',80,'egg'),(30,'Egg Bhurji',60,'egg'),(31,'Boil Egg',20,'egg'),(32,'Shahi Paneer',100,'veg'),(33,'Paneer Butter Masala',100,'veg'),(34,'Mutter Paneer',90,'veg'),(35,'Handi Paneer',80,'veg'),(36,'Kadai Paneer',90,'veg'),(37,'Paneer Tikka Masal',90,'veg'),(38,'Paneer Lababdaar',80,'veg'),(39,'Paneer Rajowari',80,'veg'),(40,'Mix Veg',75,'veg'),(41,'Malai Kofta',85,'veg'),(42,'Veg Kofta',75,'veg'),(43,'Gatta Masala',70,'veg'),(44,'Sabji Miloni',75,'veg'),(45,'Veg Jalfrezi',75,'veg'),(46,'Mashroom Masala',90,'veg'),(47,'Mashroom Matar Masala',100,'veg'),(48,'Navratna Korma',100,'veg'),(49,'Aloo Matar',60,'veg'),(50,'Aloo Palak',65,'veg'),(51,'Dum Aloo',60,'veg'),(52,'Dal Tadka',50,'veg'),(53,'Panjabi Dal Tadka',60,'veg'),(54,'Dal Fry',55,'veg'),(55,'Dal Makhni',70,'veg'),(56,'Dal Palak',60,'veg'),(57,'Tawa Roti',6,'chapati'),(58,'Tandoori Roti',8,'chapati'),(59,'Naan',20,'chapati'),(60,'Stuff Naan',30,'chapati'),(61,'Lachcha Paratha',20,'chapati'),(62,'Mix Roti',15,'chapati'),(63,'Stuff Paratha',20,'chapati'),(64,'Plain Paratha',20,'chapati'),(65,'Aloo Paratha',20,'chapati'),(66,'Paneer Paratha',60,'chapati'),(67,'Plain Rice',90,'veg_rice'),(68,'Jeera Rice',100,'veg_rice'),(69,'Mutter Pulao',120,'veg_rice'),(70,'Veg. Biryani',120,'veg_rice'),(71,'Hyderabadi Biryani',140,'veg_rice'),(72,'Egg Biryani',120,'non_veg_bi'),(73,'Chicken Biryani',230,'non_veg_bi'),(74,'Mutton Biryani',290,'non_veg_bi'),(75,'Hyderabadi Chicken Biryani',250,'non_veg_bi'),(76,'Hyderabadi Mutton Biryani',300,'non_veg_bi'),(77,'Veg Fried Rice',120,'chinese'),(78,'Egg Fried Rice',150,'chinese'),(79,'Chicken Fried Rice',180,'chinese'),(80,'Veg Noodles',80,'chinese'),(81,'Egg Noodles',120,'chinese'),(82,'Chicken Noodles',170,'chinese'),(83,'Hakka Noodles',90,'chinese'),(84,'Singapuri Noodles',100,'chinese'),(85,'American Chopsi',100,'chinese'),(86,'Chinese Bhel',80,'chinese'),(87,'Chilli Potato',60,'chinese'),(88,'Honey Chilli Potato',70,'chinese'),(89,'Veg Manchurian Dry',90,'chinese'),(90,'Veg Manchurian Gravy',100,'chinese'),(91,'Chilli Paneer',110,'chinese'),(92,'Chilli Paneer 65',120,'chinese'),(93,'Chicken Pakoda',120,'chinese'),(94,'Chicken Lolipop',200,'chinese'),(95,'Veg Roll',60,'chinese'),(96,'Egg Roll',90,'chinese'),(97,'Chicken Roll',120,'chinese'),(98,'Tomato Soup',50,'soup'),(99,'Vegitable Soup',60,'soup'),(100,'Hot & Sour Soup',60,'soup'),(101,'Fresh Cream Hop',60,'soup'),(102,'Palonto Soup',80,'soup'),(103,'Chicken Hot & Sour',100,'soup'),(104,'Plain Salad',20,'condiment'),(105,'Green Salad',30,'condiment'),(106,'Masala Papad',20,'condiment'),(107,'Peanut Masala',30,'condiment'),(108,'Veg Rayta',40,'condiment'),(109,'Onion Rayta',40,'condiment'),(110,'Bundi Rayta',40,'condiment'),(111,'Cucumber Rayta',50,'condiment'),(112,'Chaach',25,'condiment'),(113,'Lassi',40,'condiment');
/*!40000 ALTER TABLE `veg` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-05 11:20:44
